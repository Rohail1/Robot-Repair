﻿

var cols : int = 4; // no of cols
var rows : int = 4; // no of rows
var totalCards : int = cols*rows; //total cards
var matchesNeededToWin :int = totalCards*0.5; //matches needed to win must be equal to half of the cards
var matchesMade:int = 0; // initially zero
var cardW : int = 100; // card width
var cardH : int = 100; // card height
var aCards: Array; // we will store all the cards in the array
var aGrids: Array; // array to make up a grid
var aCardFlipped : ArrayList; //all the cards flipped must be in arraylist
var playerCanClick : boolean; // we will use this boolean flag to controls players clicks..
var playerHasWon : boolean = false; //initial status 


function Start () {
		
		var playerCamClick = true;
		aCards = new Array();
		aGrids = new Array();
		aCardFlipped = new ArrayList();
		BuildDeck();		
		for(var i = 0;i<rows;i++)
		{
			aGrids[i] = new Array();
			for(var j = 0;j<cols;j++)
			{
				var someNum : int = Random.Range(0, aCards.length);
				aGrids[i][j] = aCards[someNum];
				aCards.RemoveAt(someNum);
			}
		}
		
}

var CustomSkin :GUISkin;

function OnGUI () {
	
		GUILayout.BeginArea(Rect(0,0,Screen.width,Screen.height));
		BuildGrid();
		GUILayout.EndArea();
		print("Building Grid");
}

function BuildGrid()
{
		
		GUILayout.BeginVertical();
		GUILayout.FlexibleSpace();
		for(var i =0;i<rows;i++)
		{
			GUILayout.BeginHorizontal();
			GUILayout.FlexibleSpace();
			for(var j = 0;j<cols;j++)
			{
			
				var card : Object = aGrids[i][j];
				if(GUILayout.Button(Resources.Load(card.img),GUILayout.Width(cardW)))
				{
					Debug.Log(card.img);
				}
				
			}
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
		}
		GUILayout.FlexibleSpace();
		GUILayout.EndVertical();
}

function BuildDeck()
{

		var totalRobots : int = 4;
		var card: Object;
		
		for(var i = 0;i<totalRobots;i++)
		{
			var aRobotParts : Array = ["Head","Arm","Leg"];
			for(var j=0;j<2;j++)
			{
				var someNum : int = Random.Range(0,totalRobots.length);
				var missingParts : String = aRobotParts[someNum];
				aRobotParts.RemoveAt(someNum);
				card = new Card("robot"+(i+1)+"Missing"+missingParts);
				aCards.Add(card);
				card = new Card("robot"+(i+1)+missingParts);			
				aCards.Add(card);

			}
		}

}

class Card extends System.Object
{
		var isFaceUp : boolean = false;
		var isMatched : boolean = false;
		var img:String;
		
		function Card(img : String)
		{
			this.img = img;
		}
}